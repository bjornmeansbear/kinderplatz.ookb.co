#!/usr/bin/perl

#Reads a mail message. Passes the header unchanged, encrypts the body.
#Needed by mail-secure-pgp.vws. 
#Assumes that suexec is working OK and that you have ~/.pgp setup OK
#Calin Medianu 1998/04/11

$recipient = shift;
$|=1;
die ("No recipient specified\n") unless $recipient;
$body='';
@pwent=getpwuid($<);
$ENV{'PGPPATH'} = $pwent[7].'/.pgp'; 
open(OUT,"| /bin/cat");
while ($line=<STDIN>)
  {
   print OUT $line;
   if (($line eq "\n") and ($body eq ''))
     {
      close(OUT);
      open(OUT,"| /usr/local/bin/pgpe -r $recipient -a -f -t ") or 
      die("pgp $!\n");
      $body='body';
     }
  }

